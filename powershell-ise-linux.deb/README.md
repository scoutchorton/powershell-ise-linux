# Powershell ISE Linuxx
Unofficial Linux adaptation of the Microsoft Powershell ISE using Glade/Gtk3+, Python, and Powershell.
[Launchpad](https://launchpad.net/~scoutchorton/+archive/ubuntu/powershell-ise-linux)
